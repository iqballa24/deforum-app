# deforum-app
The place you can connect, learn, and share your ideas with other people

## Deploy
* [vercel](https://deforum.vercel.app/)

## Screenshot
![image](https://user-images.githubusercontent.com/57162533/211010920-b6eaefdd-92ad-4c08-b385-b4203395e236.png)
![image](https://user-images.githubusercontent.com/57162533/211010969-dfd560f3-b6c3-45fd-be58-9e98e6e774aa.png)
![image](https://user-images.githubusercontent.com/57162533/211011069-4526a1b7-7414-4029-a4dc-53fbad83e2ab.png)


